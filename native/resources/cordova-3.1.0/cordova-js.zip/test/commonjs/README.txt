This directory contains tests for the CommonJS functionality in Cordova.

The tests come from the GitHub project https://github.com/commonjs/commonjs

To run the tests, first you need to build them.

Open a shell, cd into this directory, and run `python build-tests.py`.

This will generate a set of HTML files which will run the tests within
a browser.  More instructions on how to run the tests are printed
after the tests are built.