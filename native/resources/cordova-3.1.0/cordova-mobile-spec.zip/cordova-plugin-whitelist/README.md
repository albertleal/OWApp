cordova-plugin-whitelist
------------------------

This is an optional JavaScript interface to the core Cordova Whitelist functionality. It is currently used by Mobile Spec to test the whitelist.
