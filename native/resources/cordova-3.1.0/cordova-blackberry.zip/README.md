# Apache Cordova for BlackBerry
===

This repo contains cordova projects for the BlackBerry platforms:

blackberry10 - BB10

playbook - BlackBerry Tablet OS
    git checkout 2.9.0

blackberry - BBOS 5 to 7
    git checkout 2.8.0

Please see README files in the sub folders for more information.
